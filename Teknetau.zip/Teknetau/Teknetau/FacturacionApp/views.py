# FacturacionApp/views.py
from django.shortcuts import get_object_or_404, render, redirect
from django.http import JsonResponse
from django.utils import timezone
import json
from django.http import HttpResponse
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import openpyxl
from openpyxl.styles import Font

from .models import (
    Documento, DetalleDoc, Transaccion,
    TipoTransaccion, TipoPago, FormaPago
)

from ProductoServicioApp.models import ProductoServicio
from .forms import DocumentoForm


# ============================================================
# LISTA DOCUMENTOS (ÚNICA PANTALLA)
# ============================================================

def lista_documentos(request):

    documentos = Documento.objects.all().order_by('-docum_num')

    total_docs = documentos.count()
    total_pendientes = documentos.filter(docum_estado="PENDIENTE").count()
    total_pagados = documentos.filter(docum_estado="PAGADO").count()
    total_atrasados = documentos.filter(docum_estado="ATRASADO").count()
    monto_total_bruto = sum(doc.total for doc in documentos)

    context = {
        "documentos": documentos,

        "total_docs": total_docs,
        "total_pendientes": total_pendientes,
        "total_pagados": total_pagados,
        "total_atrasados": total_atrasados,
        "monto_total_bruto": monto_total_bruto,

        "doc_form": DocumentoForm(),

        "tipos_trans": TipoTransaccion.objects.all(),
        "tipos_pago": TipoPago.objects.all(),
        "productos": ProductoServicio.objects.all(),
    }

    return render(request, "facturacion/facturacion.html", context)

# ============================================================
# ELIMINAR DOCUMENTO COMPLETO (documento + detalles + transacción)
# ============================================================

def eliminar_documento(request, pk):

    if request.method != "POST":
        return redirect("facturacionapp:lista_documentos")

    documento = get_object_or_404(Documento, pk=pk)

    forma_pago = documento.forma_pago

    documento.transacciones.all().delete()

    documento.detalles.all().delete()

    documento.delete()

    if forma_pago:
        forma_pago.delete()

    return redirect("facturacionapp:lista_documentos")



# ============================================================
# CREAR DOCUMENTO + DETALLE (UN SOLO SUBMIT)
# ============================================================

def crear_documento(request):

    if request.method != "POST":
        return redirect("facturacionapp:lista_documentos")

    form = DocumentoForm(request.POST)

    # Campos externos al form
    tipo_pago_id = request.POST.get("tipo_pago")
    dias_pago = request.POST.get("fpago_dias")
    tipo_trans_id = request.POST.get("tipo_trans")
    detalle_json = request.POST.get("detalle_json")

    # Validaciones
    if not tipo_pago_id or not dias_pago:
        documentos = Documento.objects.all()
        return render(request, "facturacion/facturacion.html", {
            "documentos": documentos,
            "doc_form": form,
            "errores": True,
            "tipos_trans": TipoTransaccion.objects.all(),
            "tipos_pago": TipoPago.objects.all(),
            "productos": ProductoServicio.objects.all(),
        })

    # Validar documento
    if not form.is_valid():
        documentos = Documento.objects.all()
        return render(request, "facturacion/facturacion.html", {
            "documentos": documentos,
            "doc_form": form,
            "errores": True,
            "tipos_trans": TipoTransaccion.objects.all(),
            "tipos_pago": TipoPago.objects.all(),
            "productos": ProductoServicio.objects.all(),
        })

    # ============================
    # 1. Crear FormaPago
    # ============================
    forma_pago = FormaPago.objects.create(
        tipo_pago_id=tipo_pago_id,
        fpago_dias=int(dias_pago)
    )

    # ============================
    # 2. Crear Documento
    # ============================
    documento = form.save(commit=False)
    documento.forma_pago = forma_pago
    documento.save()

    # ==============================
    # 3. Crear Transacción inicial 
    # ==============================
    if tipo_trans_id:
        Transaccion.objects.create(
            documento=documento,
            tipo_id=tipo_trans_id,
            trans_fecha=timezone.now().date(),
            trans_monto=0
        )

    # ===============================
    # 4. Procesar DETALLES desde JSON
    # ===============================

    """
    El JSON llega así:
    [
      {"id": "10", "cant": 2, "precio": 9000, "obs": "nota"},
      {"id": "7", "cant": 1, "precio": 15000, "obs": ""}
    ]
    """

    try:
        detalle_data = json.loads(detalle_json)
    except:
        detalle_data = []

    for item in detalle_data:

        producto = get_object_or_404(ProductoServicio, pk=item["id"])

        DetalleDoc.objects.create(
            documento=documento,
            producto=producto,
            dedoc_cant=item["cant"],
            dedoc_obs=item.get("obs", "")
        )

    # ===============================
    # 5. Actualizar monto transacción
    # ===============================

    trans = documento.transacciones.first()
    if trans:
        trans.trans_monto = documento.total
        trans.save()

    return redirect("facturacionapp:lista_documentos")


# ============================
# API: OBTENER DATOS DEL DOCUMENTO (GET)
# ============================

def api_get_documento(request, pk):

    doc = get_object_or_404(Documento, pk=pk)

    # DETALLE
    detalles = [
        {
            "id": d.producto.produ_id,
            "nombre": d.producto.produ_nom,
            "precio": int(d.producto.produ_bruto),
            "cant": d.dedoc_cant,
            "total": int(d.dedoc_cant * d.producto.produ_bruto),
            "obs": d.dedoc_obs,
        }
        for d in doc.detalles.select_related("producto").all()
    ]

    data = {

        # ================================
        # DATOS BASE PARA EDITAR
        # ================================
        "docum_num": doc.docum_num,
        "tipo_doc": doc.tipo_doc.tidoc_id,
        "empresa": doc.empresa.emppe_id,
        "proyecto": doc.proyecto.proye_idt if doc.proyecto else None,
        "docum_estado": doc.docum_estado,

        # ================================
        # FECHAS
        # ================================
        "docum_fecha_emi": doc.docum_fecha_emi.strftime("%Y-%m-%d"),
        "docum_fecha_ven": doc.docum_fecha_ven.strftime("%Y-%m-%d") if doc.docum_fecha_ven else "",
        "docum_fecha_recl": doc.docum_fecha_recl.strftime("%Y-%m-%d") if doc.docum_fecha_recl else "",

        # ================================
        # NOMBRES PARA VER DOCUMENTO
        # ================================
        "empresa_nombre": doc.empresa.emppe_nom,
        "proyecto_nombre": doc.proyecto.proye_desc if doc.proyecto else "",
        "tipo_doc_nombre": doc.tipo_doc.tidoc_tipo,

        # ================================
        # FORMA DE PAGO
        # ================================
        "tipo_pago": doc.forma_pago.tipo_pago.tpago_id if doc.forma_pago else None,
        "tipo_pago_nombre": doc.forma_pago.tipo_pago.tpago_tipo if doc.forma_pago else "",
        "fpago_dias": doc.forma_pago.fpago_dias if doc.forma_pago else "",

        # ================================
        # DETALLE
        # ================================
        "detalle": detalles,
    }

    return JsonResponse(data)


# ============================
# EDITAR DOCUMENTO (POST)
# ============================

def editar_documento_post(request, pk):

    doc = get_object_or_404(Documento, pk=pk)

    if request.method != "POST":
        return JsonResponse({"error": "Método no permitido"}, status=405)

    form = DocumentoForm(request.POST, instance=doc)
    if not form.is_valid():
        return JsonResponse({"error": "Formulario inválido", "detalles": form.errors}, status=400)

    form.save()

    # ============================
    # FORMA DE PAGO
    # ============================
    tipo_pago_id = request.POST.get("tipo_pago")
    fpago_dias = request.POST.get("fpago_dias", 0)

    if tipo_pago_id:
        tipo_pago = TipoPago.objects.get(pk=tipo_pago_id)

        FormaPago.objects.update_or_create(
            documento=doc,
            defaults={
                "tipo_pago": tipo_pago,
                "fpago_dias": fpago_dias
            }
        )

    # ============================
    # DETALLE
    # ============================
    lista = json.loads(request.POST.get("detalle_json", "[]"))

    # borrar detalle previo
    DetalleDoc.objects.filter(documento=doc).delete()

    for item in lista:
        producto = ProductoServicio.objects.get(pk=item["id"])
        DetalleDoc.objects.create(
            documento=doc,
            producto=producto,
            dedoc_cant=item["cant"],
            dedoc_obs=item.get("obs", "")
        )

    return redirect("facturacionapp:lista_documentos")


# ============================
# EXPORTAR PDF GENERAL (COMPLETO)
# ============================

def export_pdf_all(request):

    documentos = Documento.objects.all().order_by("docum_num")

    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = "attachment; filename=documentos.pdf"

    p = canvas.Canvas(response, pagesize=letter)
    y = 760

    p.setFont("Helvetica-Bold", 14)
    p.drawString(50, y, "Listado de documentos")
    y -= 40

    p.setFont("Helvetica", 10)

    for doc in documentos:

        if y < 120:     # salto de página automático
            p.showPage()
            y = 760
            p.setFont("Helvetica", 10)

        # ----- Cálculos -----
        bruto = sum(d.dedoc_cant * d.producto.produ_bruto for d in doc.detalles.all())
        neto = round(bruto / 1.19)
        iva = bruto - neto

        # ----- Encabezado del documento -----
        p.setFont("Helvetica-Bold", 11)
        p.drawString(50, y, f"Documento N° {doc.docum_num}")
        y -= 16

        p.setFont("Helvetica", 10)
        p.drawString(50, y, f"Tipo: {doc.tipo_doc.tidoc_tipo}")
        y -= 14

        p.drawString(50, y, f"Cliente: {doc.empresa.emppe_nom}")
        y -= 14

        p.drawString(50, y,
            f"Emisión: {doc.docum_fecha_emi}     Vencimiento: {doc.docum_fecha_ven or '-'}"
        )
        y -= 14

        p.drawString(50, y, f"Estado: {doc.docum_estado}")
        y -= 18

        # ----- Totales -----
        p.setFont("Helvetica-Bold", 10)
        p.drawString(50, y, f"Neto: ${neto:,}".replace(",", "."))
        y -= 14

        p.drawString(50, y, f"IVA: ${iva:,}".replace(",", "."))
        y -= 14

        p.drawString(50, y, f"Total: ${bruto:,}".replace(",", "."))
        y -= 18

        # ----- Detalle -----
        if doc.detalles.exists():
            p.setFont("Helvetica-Bold", 10)
            p.drawString(50, y, "Productos:")
            y -= 14

            p.setFont("Helvetica", 10)
            for det in doc.detalles.all():
                linea = f"- {det.producto.produ_nom} (x{det.dedoc_cant}) = ${(det.dedoc_cant * det.producto.produ_bruto):,}".replace(",", ".")
                p.drawString(60, y, linea)
                y -= 14

                if y < 80:
                    p.showPage()
                    y = 760
                    p.setFont("Helvetica", 10)

        y -= 10

    p.showPage()
    p.save()
    return response


# ============================
# EXPORTAR EXCEL GENERAL (COMPLETO)
# ============================

def export_excel_all(request):

    documentos = Documento.objects.all().order_by("docum_num")

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Documentos"

    ws.append([
        "N° Documento",
        "Cliente",
        "Tipo Documento",
        "Estado",
        "Fecha Emisión",
        "Fecha Vencimiento",
        "Neto",
        "IVA",
        "Total",
        "Productos"
    ])

    for cell in ws[1]:
        cell.font = Font(bold=True)

    for d in documentos:

        bruto = sum(det.dedoc_cant * det.producto.produ_bruto for det in d.detalles.all())
        neto = round(bruto / 1.19)
        iva = bruto - neto

        productos = ", ".join(
            f"{det.producto.produ_nom} (x{det.dedoc_cant})"
            for det in d.detalles.all()
        )

        ws.append([
            d.docum_num,
            d.empresa.emppe_nom,
            d.tipo_doc.tidoc_tipo,
            d.docum_estado,
            str(d.docum_fecha_emi),
            str(d.docum_fecha_ven or ""),
            neto,
            iva,
            bruto,
            productos
        ])

    response = HttpResponse(
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    response['Content-Disposition'] = "attachment; filename=documentos.xlsx"

    wb.save(response)
    return response
