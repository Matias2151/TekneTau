---------- COMO INICIAR EL PROGRANA ----------------

- 1 ABRIR XAMPP INICIAR MySQL Y Apache

- 2 CREAR BASE DE DATOS testdb EN PhpAdmin

- 3 ABRIR PESTAÑA SQL EN PhpAdmin 

- 4 COPIAR Y PEGAR SCRIPT QUE ESTA DENTRO DE db_seed

- 5 py manage.py makemigrations

- 6 py manage.py migrate

- 7 py manage.py runserver

 pip install openpyxl