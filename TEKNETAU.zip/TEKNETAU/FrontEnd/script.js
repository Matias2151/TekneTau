// =========================================================
// 1. LÓGICA CENTRALIZADA DEL MODO OSCURO (Tu código original)
// =========================================================

(function() {
    const root = document.documentElement; // La etiqueta <html>
    const currentTheme = localStorage.getItem('theme');
    
    // Función para alternar y guardar el nuevo tema
    function applyTheme(isDark) {
        if (isDark) {
            root.setAttribute('data-theme', 'dark');
            localStorage.setItem('theme', 'dark');
        } else {
            root.setAttribute('data-theme', 'light');
            localStorage.setItem('theme', 'light');
        }
    }

    // 1. Carga inicial del tema: Lee la preferencia guardada (GLOBAL)
    if (currentTheme) {
        root.setAttribute('data-theme', currentTheme);
    } else {
        // Valor por defecto si no hay nada guardado
        root.setAttribute('data-theme', 'light');
    }

    // 2. Manejo del interruptor (Solo si el interruptor existe en la página)
    document.addEventListener('DOMContentLoaded', () => {
        const toggleSwitch = document.getElementById('dark-mode-toggle');

        if (toggleSwitch) {
            // Sincroniza el checkbox con el tema cargado
            if (currentTheme === 'dark') {
                toggleSwitch.checked = true;
            }

            // Asigna el evento al checkbox
            toggleSwitch.addEventListener('change', () => {
                applyTheme(toggleSwitch.checked);
            });
        }
    });
})();

// =========================================================
// 2. LÓGICA DE IMPORTACIÓN DE ARCHIVOS (Facturación - Tu código original)
// =========================================================

let selectedFile = null;
const dropZone = document.getElementById('dropZone');
const fileInput = document.getElementById('fileInput');
const fileInfo = document.getElementById('fileInfo');
const fileName = document.getElementById('fileName');
const progressBar = document.getElementById('progressBar');

// Drag & Drop
if (dropZone) {
    dropZone.addEventListener('dragover', e => {
        e.preventDefault();
        dropZone.classList.add('dragover');
    });
    dropZone.addEventListener('dragleave', () => dropZone.classList.remove('dragover'));
    dropZone.addEventListener('drop', e => {
        e.preventDefault();
        dropZone.classList.remove('dragover');
        if (e.dataTransfer.files.length > 0) handleFile(e.dataTransfer.files[0]);
    });
}


function handleFileSelect(event) {
    const file = event.target.files[0];
    if (file) handleFile(file);
}

function handleFile(file) {
    const validTypes = [
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-excel',
        'text/csv'
    ];
    if (!validTypes.includes(file.type)) {
        alert('Por favor selecciona un archivo Excel válido.');
        return;
    }
    selectedFile = file;
    fileName.textContent = `📄 ${file.name}`;
    fileInfo.classList.add('show');
}

function processImport() {
    if (!selectedFile) {
        alert('Selecciona un archivo primero');
        return;
    }
    // ⚠️ NOTA: Aquí deberías hacer un FETCH POST a /api/importar con el archivo
    // La simulación de progreso se mantiene por ahora.
    let progress = 0;
    const interval = setInterval(() => {
        progress += 10;
        progressBar.style.width = progress + '%';
        progressBar.textContent = progress + '%';
        if (progress >= 100) {
            clearInterval(interval);
            setTimeout(() => {
                showSuccessModal();
            }, 500);
        }
    }, 300);
}

function cancelImport() {
    selectedFile = null;
    if(fileInfo) fileInfo.classList.remove('show');
    if(fileInput) fileInput.value = '';
}

function showSuccessModal() {
    if (document.getElementById('totalRecords')) {
        document.getElementById('totalRecords').textContent = Math.floor(Math.random() * 10) + 1;
    }
    document.getElementById('successModal').classList.add('show');
    addSampleRows(); // Función de simulación en facturación
}

// Función auxiliar para cerrar MODAL (Usada por facturacion.html)
function closeModal() {
    const modal = document.getElementById('successModal');
    if (modal) modal.classList.remove('show');
    cancelImport();
}

function addSampleRows() {
    // Lógica para añadir filas de ejemplo en la tabla de facturación
    const table = document.getElementById('invoicesTable');
    if (!table) return;
    
    const tbody = table.getElementsByTagName('tbody')[0];
    const newRow = tbody.insertRow(0);
    const rowNum = Math.floor(Math.random() * 1000) + 100;

    const estados = [
        '<span class="badge badge-success">Pagada</span>',
        '<span class="badge badge-warning">Pendiente</span>',
        '<span class="badge badge-danger">Vencida</span>',
        '<span class="badge badge-info">En Proceso</span>'
    ];
    const estadoRandom = estados[Math.floor(Math.random() * estados.length)];

    newRow.innerHTML = `
        <td>FAC-2024-${rowNum}</td>
        <td>Cliente Importado</td>
        <td>${new Date().toLocaleDateString()}</td>
        <td>${new Date(Date.now() + 15*24*60*60*1000).toLocaleDateString()}</td>
        <td>$${(Math.random() * 20000 + 5000).toFixed(0)}</td>
        <td>${estadoRandom}</td>
        <td class="action-buttons">
            <button class="btn-view"><i class="fas fa-eye"></i></button>
            <button class="btn-edit"><i class="fas fa-pencil-alt"></i></button>
            <button class="btn-delete"><i class="fas fa-trash"></i></button>
        </td>
    `;
}

// =========================================================
// 3. LÓGICA DE BACKEND / API (NUEVO CÓDIGO INTEGRADO)
// =========================================================

const API_BASE_URL = 'http://localhost:3000/api';

// Función auxiliar para obtener el JWT del almacenamiento local
function getAuthToken() {
    return localStorage.getItem('jwtToken');
}

// Función auxiliar para abrir/cerrar modal (Usada por empresa_clientes.html)
function openModal(modalId) {
    document.getElementById(modalId).classList.add('show');
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.remove('show');
    const form = document.getElementById('clientForm');
    if (form) form.reset();
}

// -------------------------------------------------
// A. CREACIÓN DE CLIENTES (Ruta POST /api/clientes)
// -------------------------------------------------

// ⚠️ Esta función reemplaza la simulación en empresa_clientes.html
async function saveClient(event) {
    event.preventDefault(); 
    
    const form = event.target;
    const formData = new FormData(form);
    const clientData = Object.fromEntries(formData.entries()); 
    
    const token = getAuthToken();
    if (!token) {
        alert("Necesitas iniciar sesión para registrar clientes.");
        return;
    }

    try {
        const response = await fetch(`${API_BASE_URL}/clientes`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}` 
            },
            body: JSON.stringify(clientData) // Enviamos los datos del formulario directamente
        });

        const result = await response.json();

        if (response.ok && response.status === 201) {
            alert('✅ Cliente registrado: ' + result.mensaje);
            // Vuelve a cargar la tabla para mostrar el nuevo cliente
            fetchClients(); 
            closeModal('addClientModal');
        } else {
            alert('❌ Error al guardar: ' + (result.mensaje || 'Error desconocido.'));
        }

    } catch (error) {
        console.error('Error de red o servidor:', error);
        alert('No se pudo conectar con el servidor Express. Asegúrate de que esté corriendo.');
    }
}

// -------------------------------------------------
// B. LECTURA DE CLIENTES (Ruta GET /api/clientes)
// -------------------------------------------------

async function fetchClients() {
    const tableBody = document.getElementById('client-list');
    if (!tableBody) return; // Solo se ejecuta en empresa_clientes.html

    const token = getAuthToken();
    if (!token) {
        tableBody.innerHTML = '<tr><td colspan="8">Por favor, inicia sesión para ver la lista de clientes.</td></tr>';
        return;
    }

    try {
        const response = await fetch(`${API_BASE_URL}/clientes`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}` 
            }
        });

        const clientList = await response.json();
        
        if (response.ok) {
            renderClientTable(clientList);
        } else {
            console.error('Error al cargar clientes:', clientList.mensaje);
            if (response.status === 403 || response.status === 401) {
                localStorage.removeItem('jwtToken');
                tableBody.innerHTML = '<tr><td colspan="8">Sesión expirada. Recarga la página.</td></tr>';
            }
        }
    } catch (error) {
        console.error('Error de conexión al obtener clientes:', error);
        tableBody.innerHTML = '<tr><td colspan="8">Error de conexión con el servidor.</td></tr>';
    }
}

function renderClientTable(clients) {
    const tableBody = document.getElementById('client-list');
    tableBody.innerHTML = ''; 

    if (clients.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="8">No hay clientes registrados.</td></tr>';
        return;
    }

    clients.forEach(client => {
        // Mapeo de valores booleanos de MySQL a textos y clases CSS
        const tipoText = client.EMPPE_EST ? 'Cliente/Proveedor' : 'No definido';
        const situacionValue = client.EMPPE_SIT ? 'Activo' : 'Inactivo';
        const tipoBadgeClass = client.EMPPE_EST ? 'badge-info' : 'badge-primary';
        const situacionBadgeClass = client.EMPPE_SIT ? 'badge-success' : 'badge-danger';

        const newRow = tableBody.insertRow();
        newRow.innerHTML = `
            <td>${client.EMPPE_RUT}</td>
            <td>${client.EMPPE_NOM}</td>
            <td>${client.EMPPE_ALIAS || 'N/A'}</td>
            <td>${client.EMPPE_FONO1}</td>
            <td>${client.EMPPE_MAIL1}</td>
            <td><span class="badge ${tipoBadgeClass}">${tipoText}</span></td>
            <td><span class="badge ${situacionBadgeClass}">${situacionValue}</span></td>
            <td class="action-buttons">
                <button class="btn-view" title="Ver Detalles"><i class="fas fa-eye"></i></button>
                <button class="btn-edit" title="Editar"><i class="fas fa-pencil-alt"></i></button>
            </td>
        `;
    });
}

// -------------------------------------------------
// C. FUNCIÓN DE CARGA INICIAL (Al cargar CUALQUIER página)
// -------------------------------------------------

// -------------------------------------------------
// D. Funciones de Login/Autenticación (DEBES CREAR UN LOGIN.HTML)
// -------------------------------------------------

async function handleLogin(event) {
    event.preventDefault();
    const form = event.target;
    const email = form.email.value;
    const password = form.password.value;
    const errorMessageElement = document.getElementById('error-message');

    try {
        const response = await fetch(`${API_BASE_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });

        const result = await response.json();

        if (response.ok) {
            // Guardamos el token y el nombre del usuario
            localStorage.setItem('jwtToken', result.token);
            localStorage.setItem('userName', result.user.nombre);
            localStorage.setItem('userRole', result.user.rol); // Guardamos el rol del usuario
            window.location.href = 'dashboard.html';
        } else {
            errorMessageElement.textContent = result.mensaje || 'Error al iniciar sesión.';
        }
    } catch (error) {
        console.error('Error de red en login:', error);
        errorMessageElement.textContent = 'No se pudo conectar al servidor.';
    }
}

function handleLogout() {
    // Limpiamos los datos de sesión del almacenamiento local
    localStorage.removeItem('jwtToken');
    localStorage.removeItem('userName');
    localStorage.removeItem('userRole'); // Limpiamos el rol
    // Redirigimos a la página de login
    window.location.href = 'login.html';
}

// -------------------------------------------------
// F. FUNCIONES DE GESTIÓN DE USUARIOS (SOLO ADMIN)
// -------------------------------------------------

async function fetchUsers() {
    const token = getAuthToken();
    try {
        const response = await fetch(`${API_BASE_URL}/users`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        const data = await response.json(); // Ahora recibimos un objeto { users, adminId }
        if (response.ok) {
            renderUsersTable(data.users, data.adminId);
        } else {
            console.error('Error al cargar usuarios:', data.mensaje);
        }
    } catch (error) {
        console.error('Error de red al obtener usuarios:', error);
    }
}

function renderUsersTable(users, adminId) {
    const tableBody = document.getElementById('user-list-table');
    if (!tableBody) return;
    tableBody.innerHTML = '';

    users.forEach(user => {
        const row = tableBody.insertRow();
        row.innerHTML = `
            <td>${user.nombre}</td>
            <td>${user.email}</td>
            <td>
                <select 
                    class="role-select" 
                    data-user-id="${user.id}" 
                    ${user.id === adminId ? 'disabled' : ''}
                >
                    <option value="usuario" ${user.rol === 'usuario' ? 'selected' : ''}>Usuario</option>
                    <option value="administrador" ${user.rol === 'administrador' ? 'selected' : ''}>Administrador</option>
                </select>
            </td>
        `;
    });

    // Añadir event listeners a los nuevos selectores
    document.querySelectorAll('.role-select').forEach(select => {
        select.addEventListener('change', async (event) => {
            const userId = event.target.dataset.userId;
            const newRole = event.target.value;
            await updateUserRole(userId, newRole);
        });
    });
}

async function updateUserRole(userId, newRole) {
    const token = getAuthToken();
    try {
        const response = await fetch(`${API_BASE_URL}/users/${userId}/role`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ rol: newRole })
        });
        const result = await response.json();
        alert(result.mensaje);
    } catch (error) {
        console.error('Error al actualizar rol:', error);
        alert('Error de red al actualizar el rol.');
    }
}

// -------------------------------------------------
// E. EVENT LISTENERS GLOBALES
// -------------------------------------------------

document.addEventListener('DOMContentLoaded', () => {
    // Cargar componentes reutilizables (sidebar y header) en todas las páginas.
    loadComponent('.sidebar', 'sidebar.html');
    loadComponent('.top-header', 'header.html');

    // --- LÓGICA DE SESIÓN DE USUARIO ---
    const token = getAuthToken();
    const userName = localStorage.getItem('userName');
    const userRole = localStorage.getItem('userRole');
    const currentPage = window.location.pathname.split('/').pop();

    if (token && userName) {
        // Si hay token y estamos en la página de login, redirigir al dashboard
        if (currentPage === 'login.html') {
            window.location.href = 'dashboard.html';
            return;
        }

        // Actualizar el nombre de usuario en la cabecera
        const userNameDisplay = document.getElementById('user-name-display');
        if (userNameDisplay) {
            userNameDisplay.textContent = userName;
        }

        // Asignar evento al botón de logout
        const logoutButton = document.getElementById('logout-button');
        if (logoutButton) {
            logoutButton.addEventListener('click', handleLogout);
        }

        // --- LÓGICA DE ADMINISTRADOR ---
        if (userRole === 'administrador') {
            const adminSection = document.getElementById('admin-section');
            if (adminSection) {
                adminSection.classList.remove('hidden'); // Mostrar la sección de admin
                fetchUsers(); // Cargar la lista de usuarios

                // Añadir funcionalidad de búsqueda a la tabla de usuarios
                const searchInput = document.getElementById('user-search-input');
                if (searchInput) {
                    searchInput.addEventListener('keyup', () => {
                        const searchTerm = searchInput.value.toLowerCase();
                        const tableRows = document.querySelectorAll('#user-list-table tr');
                        
                        tableRows.forEach(row => {
                            const userName = row.cells[0].textContent.toLowerCase();
                            // Si el nombre del usuario incluye el término de búsqueda, se muestra la fila
                            row.style.display = userName.includes(searchTerm) ? '' : 'none';
                        });
                    });
                }
            }
        }

    } else if (currentPage !== 'login.html' && currentPage !== '') {
        // Si no hay token y no estamos en la página de login, redirigir al login
        window.location.href = 'login.html';
    }

    // Asignar eventos a los formularios de login y registro si existen
    const loginForm = document.getElementById('login-form');
    if (loginForm) loginForm.addEventListener('submit', handleLogin);

    // Cargar clientes si estamos en la página de clientes
    if (document.getElementById('client-list')) {
        fetchClients();
    }
    
    // Asignar evento al formulario de creación de clientes
    const clientForm = document.getElementById('clientForm');
    if (clientForm) {
        clientForm.onsubmit = saveClient;
    }
});

// =========================================================
// G. CARGA DINÁMICA DE COMPONENTES REUTILIZABLES (SIDEBAR/HEADER)
// =========================================================

/**
 * Carga un componente HTML reutilizable en un elemento específico.
 * @param {string} selector - El selector CSS del elemento contenedor (ej: '.sidebar').
 * @param {string} url - La URL del archivo HTML del componente (ej: 'sidebar.html').
 */
async function loadComponent(selector, url) {
    const element = document.querySelector(selector);
    if (element) {
        try {
            const response = await fetch(url);
            if (response.ok) {
                element.innerHTML = await response.text();
                if (selector === '.sidebar') {
                    setActiveLink(); // Marcar el enlace activo después de cargar la barra lateral
                }
            } else {
                console.error(`Error al cargar el componente '${url}': ${response.statusText}`);
            }
        } catch (error) {
            console.error(`Error de red al cargar '${url}':`, error);
        }
    }
}

/**
 * Marca el enlace de navegación actual como activo en la barra lateral.
 */
function setActiveLink() {
    const currentPage = window.location.pathname.split('/').pop();
    const navLinks = document.querySelectorAll('.sidebar-nav a');
    navLinks.forEach(link => {
        if (link.getAttribute('href') === currentPage) {
            link.parentElement.classList.add('active');
        }
    });
}

// Cargar los componentes comunes en todas las páginas al iniciar.
document.addEventListener('DOMContentLoaded', () => {
    loadComponent('.sidebar', 'sidebar.html');
    loadComponent('.top-header', 'header.html');
});