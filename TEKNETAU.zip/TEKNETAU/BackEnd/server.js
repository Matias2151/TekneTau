require('dotenv').config(); // Carga las variables de entorno desde .env
const express = require('express');
const path = require('path');
const cors = require('cors');
const pool = require('./config/db'); // Importa el pool de conexiones

// Importar rutas
const authRoutes = require('./routes/authRoutes');
const clientRoutes = require('./routes/clientRoutes');
const userRoutes = require('./routes/userRoutes'); // <-- Nueva ruta

const app = express();
const port = process.env.PORT || 3000;

// ----------------------------------------------------
// 1. MIDDLEWARES GENERALES
// ----------------------------------------------------

// 1.1 Middleware para permitir peticiones de otros orígenes (FrontEnd)
app.use(cors());

// 1.2 Middleware para leer JSON del body de las peticiones
app.use(express.json());

// 1.3 Middleware para servir el frontend estático (opcional, pero útil)
app.use(express.static(path.join(__dirname, '..', 'FrontEnd')));

// ----------------------------------------------------
// 2. RUTAS DE LA API
// ----------------------------------------------------

// Rutas de autenticación (públicas)
app.use('/api/auth', authRoutes);

// Rutas de clientes (protegidas)
app.use('/api/clientes', clientRoutes);

// Rutas de gestión de usuarios (protegidas para admin)
app.use('/api/users', userRoutes); // <-- Nueva ruta

// ----------------------------------------------------
// 3. INICIO DEL SERVIDOR
// ----------------------------------------------------

// Ruta principal para servir el index.html
app.get('/', (req, res) => {
    // Idealmente, deberías tener un login.html como página de inicio
    res.sendFile(path.join(__dirname, '..', 'FrontEnd', 'login.html'));
});

app.listen(port, () => {
    console.log(`Servidor Express corriendo en http://localhost:${port}`);
    console.log(`Para detenerlo, presiona Ctrl + C.`);
});