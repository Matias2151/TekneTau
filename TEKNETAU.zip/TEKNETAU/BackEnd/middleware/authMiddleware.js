const jwt = require('jsonwebtoken');

function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Formato "Bearer TOKEN"

    if (token == null) {
        return res.status(401).json({ mensaje: 'Acceso denegado. No se proporcionó token.' });
    }

    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if (err) {
            return res.status(403).json({ mensaje: 'Token inválido o expirado.' });
        }
        // Adjuntamos los datos del usuario (incluyendo el rol) a la petición
        req.user = user;
        next(); // El usuario es válido, puede continuar
    });
}

module.exports = authenticateToken;