const pool = require('../config/db');

// Obtener todos los usuarios (para el admin)
exports.getAllUsers = async (req, res) => { // El req.user viene del middleware de autenticación
    try {
        // Obtenemos todos los usuarios
        const [users] = await pool.query('SELECT id, nombre, email, rol FROM usuarios');
        // Devolvemos los usuarios y el ID del admin que hace la petición
        res.json({ users, adminId: req.user.id });
    } catch (error) {
        console.error('Error al obtener usuarios:', error);
        res.status(500).json({ mensaje: 'Error interno del servidor.' });
    }
};

// Actualizar el rol de un usuario
exports.updateUserRole = async (req, res) => {
    const { id } = req.params;
    const { rol } = req.body;
    const adminId = req.user.id; // Obtenemos el ID del admin que hace la petición

    if (!rol || (rol !== 'administrador' && rol !== 'usuario')) {
        return res.status(400).json({ mensaje: 'Rol no válido.' });
    }

    try {
        await pool.query('UPDATE usuarios SET rol = ? WHERE id = ?', [rol, id]);
        res.json({ mensaje: 'Rol de usuario actualizado correctamente.' });
    } catch (error) {
        console.error('Error al actualizar el rol:', error);
        res.status(500).json({ mensaje: 'Error interno del servidor.' });
    }
};