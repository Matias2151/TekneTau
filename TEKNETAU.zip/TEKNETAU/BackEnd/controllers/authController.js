const pool = require('../config/db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const saltRounds = 10;

// Controlador para el inicio de sesión
exports.loginUser = async (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
        return res.status(400).json({ mensaje: 'Faltan email o contraseña.' });
    }

    try {
        const [rows] = await pool.query('SELECT * FROM usuarios WHERE email = ?', [email]);
        const user = rows[0];

        if (!user) {
            return res.status(401).json({ mensaje: 'Credenciales inválidas.' });
        }

        const match = await bcrypt.compare(password, user.password);
        if (!match) {
            return res.status(401).json({ mensaje: 'Credenciales inválidas.' });
        }

        // Si las credenciales son correctas, generar el JWT
        const payload = { id: user.id, email: user.email, nombre: user.nombre, rol: user.rol }; // Añadimos el ROL al payload
        const token = jwt.sign(
            payload, 
            process.env.JWT_SECRET, 
            { expiresIn: '1h' } // El token expirará en 1 hora
        );

        res.json({ 
            mensaje: 'Inicio de sesión exitoso', 
            token,
            // Enviamos los datos del usuario (incluyendo el rol) al frontend
            user: { nombre: user.nombre, rol: user.rol }
        });

    } catch (error) {
        console.error('Error en el login:', error);
        res.status(500).json({ mensaje: 'Error interno del servidor.' });
    }
};
