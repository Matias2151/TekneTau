const pool = require('../config/db');

// @desc    Obtener todos los clientes
// @route   GET /api/clientes
// @access  Private
exports.getAllClients = async (req, res) => {
    try {
        const query = `SELECT EMPPE_RUT, EMPPE_NOM, EMPPE_ALIAS, EMPPE_FONO1, EMPPE_MAIL1, EMPPE_EST, EMPPE_SIT FROM EMPRESAPERSONA`;
        const [rows] = await pool.query(query);
        res.json(rows);
    } catch (error) {
        console.error('Error al obtener clientes:', error);
        res.status(500).json({ mensaje: 'Error al obtener datos de clientes.' });
    }
};

// @desc    Crear un nuevo cliente
// @route   POST /api/clientes
// @access  Private
exports.createClient = async (req, res) => {
    const { emppe_rut, emppe_nom, emppe_alias, emppe_fono1, emppe_mail1, emppe_char, emppe_gits } = req.body;

    // Lógica para determinar los valores booleanos basados en el texto del formulario
    // MEJORA: Se usa .includes() para ser más flexible. Si el texto contiene "Cliente", se considera como tal.
    // Esto cubre "Cliente" y "Cliente/Proveedor".
    const emppe_est = emppe_char.includes('Cliente');

    const emppe_sit = emppe_gits === 'ACTIVO';
    // SOLUCIÓN: Usamos null en lugar de un ID fijo.
    // Esto evita el error de clave foránea hasta que se implemente la gestión de direcciones.
    const emppe_dire_id = null; 

    try {
        const query = `
            INSERT INTO EMPRESAPERSONA 
            (EMPPE_RUT, EMPPE_NOM, EMPPE_ALIAS, EMPPE_FONO1, EMPPE_FONO2, EMPPE_MAIL1, EMPPE_EST, EMPPE_SIT, EMPPE_DIRE_ID) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;
        
        const [result] = await pool.query(query, [
            emppe_rut, 
            emppe_nom, 
            emppe_alias || null, 
            emppe_fono1, 
            null, // FONO2 vacío
            emppe_mail1, 
            emppe_est,
            emppe_sit,
            emppe_dire_id 
        ]);
        
        res.status(201).json({ mensaje: 'Empresa/Persona registrada correctamente', id: result.insertId });

    } catch (error) {
        console.error('Error al registrar empresa/persona:', error);
        res.status(500).json({ mensaje: 'Error al registrar la entidad.' });
    }
};