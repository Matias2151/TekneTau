const express = require('express');
const router = express.Router();
const { getAllUsers, updateUserRole } = require('../controllers/userController');
const authenticateToken = require('../middleware/authMiddleware');

// Middleware para verificar si el usuario es administrador
const isAdmin = (req, res, next) => {
    if (req.user && req.user.rol === 'administrador') {
        next();
    } else {
        res.status(403).json({ mensaje: 'Acceso denegado. Se requiere rol de administrador.' });
    }
};

// @route   GET api/users
router.get('/', [authenticateToken, isAdmin], getAllUsers);

// @route   PUT api/users/:id/role
router.put('/:id/role', [authenticateToken, isAdmin], updateUserRole);

module.exports = router;