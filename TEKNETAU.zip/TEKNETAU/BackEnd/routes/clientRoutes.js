const express = require('express');
const router = express.Router();
const { getAllClients, createClient } = require('../controllers/clientController');
const authenticateToken = require('../middleware/authMiddleware');

// Todas las rutas de clientes ahora requerirán un token válido.

// @route   GET api/clientes
// @desc    Obtener todos los clientes
// @access  Private
router.get('/', authenticateToken, getAllClients);

// @route   POST api/clientes
// @desc    Crear un nuevo cliente
// @access  Private
router.post('/', authenticateToken, createClient);

module.exports = router;